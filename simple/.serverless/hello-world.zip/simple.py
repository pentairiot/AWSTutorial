def hello(event, context):

    response = {
        "statusCode": 200,
        "body": 'hello, world'
    }

    return response
